let svg;
document.addEventListener('DOMContentLoaded', () => {
    // Set the dimensions and margins of the graph
    const margin = { top: 30, right: 30, bottom: 50, left: 60 },
        width = 900 - margin.left - margin.right,
        height = 650 - margin.top - margin.bottom;

    // Append the svg object to the body of the page
    svg = d3.select("#my_dataviz")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    // Load the data
    d3.csv("./data/Final_df.csv").then(function (data) {

        // Get room types
        const roomTypes = Array.from(new Set(data.map(d => d.room_type)));
        const roomTypeNames = ['Entire home/apt', 'Private room', 'Shared room'];

        // Add X axis
        const x = d3.scaleBand()
            .domain(data.map(d => d.cityName))
            .range([0, width])
            .padding(0.2);

        const xAxis = svg.append("g")
            .attr("transform", `translate(0, ${height})`)
            .call(d3.axisBottom(x));

        // X axis label
        svg.append("text")
            .attr("transform",
                "translate(" + (width / 2) + " ," +
                (height + margin.top + 10) + ")")
            .style("text-anchor", "middle")
            .text("City (Click on city for filtering)")
            .style("font-size", "18px")
            .style("font-family", "'Source Sans Pro', sans-serif");

        // Add Y axis
        const y = d3.scaleLinear()
            .domain([0, d3.max(data, d => +d.realSum)])
            .nice()
            .range([height, 0]);

        svg.append("g")
            .call(d3.axisLeft(y));

        // Y axis label
        svg.append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", 0 - margin.left - 5)
            .attr("x", 0 - (height / 2))
            .attr("dy", "1em")
            .style("text-anchor", "middle")
            .style("font-family", "'Source Sans Pro', sans-serif")
            .text("Price (In Euros)");

        // Color
        const color = d3.scaleOrdinal()
            .domain(roomTypes)
            .range(['#BA99DC', '#86D1F1', '#B3F0C8']);

        // Define tooltip
        const tooltip = d3.select("#tooltip");

        // Show the bars
        svg.selectAll(".bar")
            .data(data)
            .enter().append("rect")
            .attr("class", "bar bar-item")
            .attr("x", d => x(d.cityName) + x.bandwidth() / roomTypes.length * roomTypes.indexOf(d.room_type))
            .attr("y", d => y(+d.realSum))
            .attr("width", x.bandwidth() / roomTypes.length)
            .attr("height", d => height - y(+d.realSum))
            .attr("fill", d => color(d.room_type))
            .on("mouseover", function (event, d) {
                const count = data.filter(item => item.cityName === d.cityName && item.room_type === d.room_type).length;
                tooltip.style("opacity", 1)
                    .html("No of airbnbs: " + count)
                    .style("left", (event.pageX + 10) + "px")
                    .style("top", (event.pageY - 28) + "px");
            })
            .on("mouseout", function (event, d) {
                tooltip.style("opacity", 0);
            });

        // Add click event listener to x-axis labels
        xAxis.selectAll("text")
        .style("cursor", "pointer")
        .on("click", function(event, d) {
            const selectedCity = d;

            // event to synchronize with density plot
            var event = new CustomEvent('citySelected', { detail: selectedCity });
            document.dispatchEvent(event);
        });


        // Legend
        const legend = svg.selectAll(".legend")
            .data(roomTypeNames)
            .enter().append("g")
            .attr("class", "legend")
            .attr("transform", (d, i) => "translate(0," + i * 20 + ")");

        legend.append("rect")
            .attr("x", width - 18)
            .attr("width", 18)
            .attr("height", 18)
            .style("fill", color)

            .style("font-family", "'Source Sans Pro', sans-serif");

        legend.append("text")
            .attr("x", width - 24)
            .attr("y", 9)
            .attr("dy", ".35em")
            .style("text-anchor", "end")
            .style("font-size", "18px")
            .style("font-family", "'Source Sans Pro', sans-serif")
            .text(d => d);

        // button for "All Cities"
        const allCitiesButton = svg.append("g")
        .attr("class", "legend")
        .attr("transform", "translate(0," + (roomTypeNames.length * 20 + 10) + ")");

        const buttonWidth = 145;
        const buttonHeight = 25;

        allCitiesButton.append("rect")
            .attr("x", width - buttonWidth - 1) // x-coordinate
            .attr("width", buttonWidth)
            .attr("height", buttonHeight)
            .style("fill", "#415c90")
            .style("cursor", "pointer")
            .on("click", function() {
                // event to show all bars
                var event = new CustomEvent('citySelected', { detail: "All Cities" });
                document.dispatchEvent(event);
            });

        allCitiesButton.append("text")
            .attr("x", width - buttonWidth + 100) // x-coordinate
            .attr("y", buttonHeight / 2) // vertically
            .attr("dy", ".35em")
            .style("text-anchor", "end")
            .style("font-size", "18px")
            .style("fill", "white")
            .style("font-family", "'Source Sans Pro', sans-serif")
            .text("All Cities")
            .style("cursor", "pointer")
            .on("click", function() {
                // Animate bars
                svg.selectAll(".bar")
                .attr("y", height) // initial position at the bottom
                .transition()
                .duration(1500) // duration in milliseconds
                .attr("y", d => y(+d.realSum)); // Move bars to final position

                // event to show all bars
                var event = new CustomEvent('citySelected', { detail: "All Cities" });
                document.dispatchEvent(event);
            });

    });


        // event to synchronize with density chart
        document.addEventListener('citySelected', function(event) {
            const selectedCity = event.detail;
            const bars = svg.selectAll(".bar");
        
            if (selectedCity === "All Cities") {
                bars.style("display", "block"); // Show all bars
            } else {
                bars.style("display", function(d) {
                    return d.cityName === selectedCity ? "block" : "none";
                });
            }
            });
    });
    document.addEventListener('densityPlotButtonClicked', function(event) {
        const clickedButton = event.detail;
        const bars = svg.selectAll(".bar-item");
    
        if (clickedButton === "Metro Distance") {
            bars.style("display", "block"); // Show all bars
        } else {
            bars.style("display", "block"); // Show all bars for both buttons
        }
    });
