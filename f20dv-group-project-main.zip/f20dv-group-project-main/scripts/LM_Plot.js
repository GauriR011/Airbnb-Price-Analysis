// The export keyword is used to export the LM_Plot class so that it can be imported in other files
export default class LM_Plot {

    // Object properties
    width; height; margin;
    svg; chart; regression_line; axisX; axisY; labelX; labelY;
    scaleX; scaleY;
    data; xdata; data; groupedData;
    flag;

// Constructor: defines setup size and selections
// Parameters: (div container selector, width, height, margin [top,right,bottom,left])
constructor(container, width, height, margin) {
    this.width = width;
    this.height = height;
    this.margin = margin;
    this.svg = d3.select(container).append('svg')
        .classed('scatter-plot vis', true)
        .attr('width', this.width).attr('height', this.height);
    this.chart = this.svg.append('g')
        .attr('transform', `translate(${this.margin.left},${this.margin.top})`);
    this.regression_line = this.chart.selectAll('line.regression_line');
    this.axisX = this.svg.append('g')
        .attr('transform', `translate(${this.margin.left},${this.height-this.margin.bottom})`);
    this.axisY = this.svg.append('g')
        .attr('transform', `translate(${this.margin.left},${this.margin.top})`);
    this.labelX = this.svg.append('text').style('font-size', '20px').classed('legend', true)
        .attr('transform', `translate(${this.width/2},${this.height})`)
        .style("font-family", "'Source Sans Pro', sans-serif")
        .style('text-anchor', 'middle').attr('dy',-15);
    this.labelY = this.svg.append('text').style('font-size', '20px').classed('legend', true)
        .attr('transform', `translate(0,${this.height/4})rotate(-90)`)
        .style("font-family", "'Source Sans Pro', sans-serif")
        .style('text-anchor', 'end').attr('dy',15);
}

 // Private methods

 // This function updates the scales necessary for rendering the visualization based on the 
 // domain and range.
#updateScales(){
    // the width and height of the chart is calcualted based on overall width, height and margins.
    let chartWidth = this.width - this.margin.left - this.margin.right,
        chartHeight = this.height - this.margin.top - this.margin.bottom;

    let rangeX = [0, chartWidth],
        rangeY = [chartHeight, 0];
    let domainX = [0, d3.max(this.xdata)],
        domainY = [0, d3.max(this.ydata)];

    // a linear scale is created for the X and Y axis
    // nice() is used to round numbers
    this.scaleX = d3.scaleLinear(domainX, rangeX).nice();  
    this.scaleY = d3.scaleLinear(domainY, rangeY).nice();
}

// This function ensures that the X and Y axes are updated according to the scales. 
// A smooth transition effect is applied to the Y axis.
#updateAxes(){
    let axisGenX = d3.axisBottom(this.scaleX),
        axisGenY = d3.axisLeft(this.scaleY).tickFormat(this.axisYFormat);
    this.axisX.call(axisGenX);
    this.axisY.transition().duration(300).call(axisGenY);
}

// This function updates the linear regression lines calculated for each city based on the 
// option selected (Restaurant Index / Attraction Index).
#updateLines() {
    let anim = 300;
    var colorScale = d3.scaleOrdinal(d3.schemeCategory10);
    const sortedCities = Array.from(this.groupedData.keys()).sort();
colorScale.domain(sortedCities);

this.regression_line = this.regression_line
    .data(sortedCities.map(function (cityName) {
        const cityData = this.groupedData.get(cityName);
        const cityXData = this.flag ? cityData.map(d => +d.rest_index) : cityData.map(d => +d.attr_index);
        const cityYData = cityData.map(d => +d.realSum);
        const regression = calcLinearRegression(cityXData, cityYData); 
        return { cityName, regression, cityXData, cityYData };
    }, this))
    .join( // drawing the regression line for each city
        enter => enter.append('line')
            .attr('x1', d => this.scaleX(d3.min(d.cityXData)))
            .attr('y1', d => this.scaleY(d.regression.ptA.y))
            .attr('x2', d => this.scaleX(d3.min(d.cityXData)))
            .attr('y2', d => this.scaleY(d.regression.ptA.y))
            .style('stroke', d => colorScale(d.cityName))  // Customize the line color for each city
            .style('stroke-width', 5),
        update => update,
        exit => exit.transition().duration(anim) //Applying animations to transitions
            .attr('x2', d => this.scaleX(d3.min(d.cityXData)))
            .attr('y2', d => this.scaleY(d.regression.ptA.y))
            .remove()
    )
    .classed('regression_line', true);
    
    //applying animation for a smooth transition 
    this.regression_line.transition().duration(anim)
        .attr('x1', d => this.scaleX(d3.min(d.cityXData)))
        .attr('y1', d => this.scaleY(d.regression.ptA.y))
        .attr('x2', d => this.scaleX(d3.max(d.cityXData)))
        .attr('y2', d => this.scaleY(d.regression.ptB.y));
        

        // creating a legend
        var legend = this.svg.append('g')
        .attr('class', 'legend')
        .attr('transform', `translate(${this.width - this.margin.right - 150},${this.margin.top})`);

        const legendItems = legend.selectAll('.legend-item')
        .data(Array.from(this.groupedData.keys()))
        .enter().append('g')
        .attr('class', 'legend-item')
        .attr('transform', (d, i) => `translate(0, ${i * 20})`);

        // representing the colour of the lines
        legendItems.append('rect')
        .attr('width', 15)
        .attr('height', 15)
        .style("font-family", "'Source Sans Pro', sans-serif")
        .attr('fill', d => colorScale(d)); 

        // representing the cities
        legendItems.append('text')
            .attr('x', 25)
            .attr('y', 13)
            .style('font-size', '18px')
            .style("font-family", "'Source Sans Pro', sans-serif")
            .text(d => d);

    
    // This function calculate the line of the linear regression by calculating the slope,
    // intercept and the 2 points to be connected to plot the line.

    // Parameters: (X axis values (restIndex/attrIndex), Y axis values (realSum))
    function calcLinearRegression(xdata, ydata) {
        var n = xdata.length;
        var sumX = d3.sum(xdata);
        var sumY = d3.sum(ydata);
        var sumXY = d3.sum(xdata.map((d, i) => d * ydata[i]));
        var sumXSquare = d3.sum(xdata.map(d => d * d));

        var slope = (n * sumXY - sumX * sumY) / (n * sumXSquare - sumX * sumX);
        var intercept = (sumY - slope * sumX) / n;

        return {
            slope: slope,
            intercept: intercept,
            ptA: { x: d3.min(xdata), y: slope * d3.min(xdata) + intercept },
            ptB: { x: d3.max(xdata), y: slope * d3.max(xdata) + intercept }
        };   
    } 
}

// Public API

//This method renders the visualization
// Parameters: (dataset, column on x axis, column on y axis, data grouped by cities , true/false)
render(dataset, xdata, ydata, groupedData, flag){
    this.data = dataset;
    this.xdata = xdata; 
    this.ydata = ydata; 
    this.flag = flag;
    this.groupedData = groupedData;
    this.#updateScales();
    this.#updateLines();
    this.#updateAxes();
    return this;
};

// This method sets labels for the X and Y axes.
setLabels(labelX='categories', labelY='values'){
    this.labelX.text(labelX);
    this.labelY.text(labelY);
    return this;
};


}


