'use strict';

// Module imports
import LM_Plot from './LM_Plot.js';

// LOADING DATA
let xRdata, xAdata, ydata, groupedData ;
let dataset = await d3.csv("./data/Final_df.csv").then(function(data) {

    // Filter data where realSum < 2000
    var filteredData = data.filter(d => +d.realSum < 2000);

    // Extract X and Y data from filtered data
    xRdata = filteredData.map(d => +d.rest_index);
    xAdata = filteredData.map(d => +d.attr_index);

    ydata = filteredData.map(d => +d.realSum);

    // Group filtered data by city
    groupedData = d3.group(filteredData, d => d.cityName);

});

//Initializing width, height and margins to position the the visualization within these boundaries. 
let width = 1000;
let height = 600;
let margin = { top: 20, right: 15, bottom: 60, left: 60 };

// displaying a default visualization
let LM_plot = new LM_Plot('#LM_Plot', width, height, margin);
LM_plot.setLabels('Restautrant Index (Proximity of Restautants)', 'Price  (in Euros)')
.render(dataset, xRdata, ydata, groupedData, true);

//Buttons to switch between the 2 plots
var container = d3.select('#LM_Plot_buttons')

//Button for Restaurant Index
container.append('button')
                .text('Restaurant Index').style('font-size', '20px')
                .style("font-family", "'Source Sans Pro', sans-serif")
                .style('margin-right', '50px')
                .style('margin-left', '220px')
                .classed('button_rest', true)
                .classed('button', true)
                .classed('clicked', true)
                .on('click', ()=>{
                    d3.select('.button_rest').classed('clicked', true);
                    d3.select('.button_attr').classed('clicked', false);
    LM_plot.setLabels('Restautrant Index (Proximity of Restautants)', 'Price  (in Euros)')
        .render(dataset, xRdata, ydata, groupedData, true);
})


//Button for Attraction Index
container.append('button')
                .text('Attraction Index').style('font-size', '20px')
                .style("font-family", "'Source Sans Pro', sans-serif")
                .classed('button_attr', true)
                .classed('button', true)
                .classed('clicked', false)
                .on('click', ()=>{
                    d3.select('.button_attr').classed('clicked', true);
                    d3.select('.button_rest').classed('clicked', false);
    LM_plot.setLabels('Attraction Index (Proximity of Tourist Attractions)', 'Price  (in Euros)')
        .render(dataset, xAdata, ydata, groupedData, false)
})
