d3.csv("./data/Final_df.csv").then(function(data) { //loading the data from csv file
    console.log("Data loaded:", data);

    // Filtering out the records with prices > 700
    data = data.filter(function(d) {
        return +d.realSum <= 700;
    });
    console.log("Filtered data:", data);

    // Grouping data by city
    var nestedData = d3.group(data, d => d.cityName);
    console.log("Nested data:", nestedData);

    // Defining color scale for cities
    var color = d3.scaleOrdinal(d3.schemeCategory10)
        .domain(nestedData.keys());

    // Defining initial scales for x and y axes
    var xScale = d3.scaleLinear()
        .domain([0, 7])
        .range([50, 750]);

    var yScale = d3.scaleLinear()
        .domain([0, 1.5]) 
        .range([500, 50]);

    // defining width and height for density plot
    var width = 900;
    var height = 600;

    // Creating SVG
    var svg = d3.select("#densityPlot").append("svg")
        .attr("width", width)
        .attr("height", height);

    svg.append("g")
        .attr("class", "x-axis")
        .attr("transform", "translate(0," + yScale.range()[0] + ")")
        .call(d3.axisBottom(xScale));

    svg.append("g")
        .attr("class", "y-axis")
        .attr("transform", "translate(" + xScale.range()[0] + ",0)")
        .call(d3.axisLeft(yScale));

    // Appending x-axis label
    var xAxisLabel = svg.append("text")
        .attr("class", "x-axis-label")
        .attr("text-anchor", "middle")
        .attr("transform", "translate(" + (width / 2) + "," + (height - 50) + ")")
        .text("Metro Distance (in Km)");

    // Appending y-axis label
    var yAxisLabel = svg.append("text")
        .attr("class", "y-axis-label")
        .attr("text-anchor", "middle")
        .attr("transform", "translate(" + 20 + "," + (height / 2) + ")rotate(-90)")
        .text("Price Density");

    // Function to update density plot for each city with animation
    function updateDensityPlot(property) {
        // Removes existing lines with transition
        svg.selectAll(".line")
            .transition()
            .duration(500) // Adjusts duration 
            .style("opacity", 0)
            .remove();

        // Adjusting xScale domain for "Distance from City Centre" button
        if (property === "dist") {
            xScale.domain([0, 14]);
            xAxisLabel.text("Distance from City Centre (in Km)");
        } else {
            xScale.domain([0, 7]);
            xAxisLabel.text("Metro Distance (in Km)");
        }

    // Creating density plot for each city with animation
    nestedData.forEach(function(cityData, cityName) {
        var density = kernelDensityEstimator(kernelEpanechnikov(0.5), xScale.ticks(100));

        var densityData = density(cityData.map(function(d) {
            return +d[property];
        }));

        var line = d3.line()
            .x(function(d) { return xScale(d[0]); })
            .y(function(d) { return yScale(d[1]); });

        // Appending new path with animation
        svg.append("path")
            .datum(densityData)
            .attr("class", "line line-" + sanitizeClassName(cityName))
            .attr("fill", "none")
            .attr("stroke", color(cityName))
            .attr("stroke-width", 2)
            .attr("d", line)
            .style("opacity", 0) // Set initial opacity to 0
            .transition()
            .duration(1000) // Adjusts duration
            .style("opacity", 1); // Fade in
    });

    // Updates x-axis with transition
    svg.select(".x-axis")
        .transition()
        .duration(500) // Adjusts duration
        .call(d3.axisBottom(xScale));

    // Updates legend
    updateLegend();
}
    // Function to update legend
    function updateLegend() {
        // Removes existing legend
        svg.selectAll(".legend").remove()
        // Legend title
        svg.append("text")
            .attr("class", "legend-title")
            .attr("x", width - 50)
            .attr("y", 10)
            .attr("dy", ".35em")
            .style("text-anchor", "middle")
            .text("Select City!")
            .style("fill", "black")
            .style("font-weight", "bold")
            .style("font-family", "'Source Sans Pro', sans-serif")
            .style("font-size", "20px");

        var legend = svg.selectAll(".legend")
            .data(nestedData.keys())
            .enter()
            .append("g")
            .attr("class", "legend")
            .attr("transform", function(d, i) {
                return "translate(0," + (i * 30) + ")";
            })
            .on("click", function(event, cityName) {
                console.log("Clicked city:", cityName);

                // Hide all city lines except the clicked city
                svg.selectAll("path.line")
                    .style("display", function(d) {
                        var isSelectedCity = d3.select(this).attr("class").includes(sanitizeClassName(cityName));
                        return isSelectedCity ? "block" : "none";
                    });
            });

        // Add rectangular color boxes
        legend.append("rect")
            .attr("x", width - 100)
            .attr("y", 30)
            .attr("width", 300)
            .attr("height", 20)
            .style("fill", function(d) { return color(d); })
            .style("font-family", "'Source Sans Pro', sans-serif")
            .style("cursor", "pointer");

        // label for city names
        legend.append("text")
            .attr("x", width - 50)
            .attr("y", 40)
            .attr("dy", ".35em")
            .style("text-anchor", "middle")
            .style("font-family", "'Source Sans Pro', sans-serif")
            .text(function(d) { return d; })
            .style("fill", "white")
            .style("cursor", "pointer")
            .on("click", function(event, cityName) {
                console.log("Clicked city:", cityName);

                // Hides all city lines except the clicked city
                svg.selectAll("path.line")
                    .style("display", function(d) {
                        var isSelectedCity = d3.select(this).attr("class").includes(sanitizeClassName(cityName));
                        return isSelectedCity ? "block" : "none";
                    });

                // Dispatch custom event to synchronize with bar chart
                var event = new CustomEvent('citySelected', { detail: cityName });
                document.dispatchEvent(event);
            });

        // Legend for "All Cities"
        var allCitiesLegend = svg.append("g")
            .attr("class", "legend")
            .attr("transform", "translate(0," + (nestedData.size * 30 + 30) + ")");

        // Add rectangular color box for "All Cities"
        allCitiesLegend.append("rect")
            .attr("x", width - 100)
            .attr("y", 1)
            .attr("width", 300)
            .attr("height", 20)
            .style("fill", "#FDE9AF") // color 
            .style("cursor", "pointer");

        // label for "All Cities"
        allCitiesLegend.append("text")
            .attr("x", width - 50)
            .attr("y", 10)
            .attr("dy", ".35em")
            .style("text-anchor", "middle")
            .text("All Cities")
            .style("font-family", "'Source Sans Pro', sans-serif")
            .style("fill", "black")
            .style("cursor", "pointer")
            .on("click", function() {
                // Shows all city lines
                svg.selectAll("path.line")
                    .style("display", "block");

                // Dispatch custom event to synchronize with bar chart for "All Cities"
                var event = new CustomEvent('citySelected', { detail: "All Cities" });
                document.dispatchEvent(event);
            });
    }

    // Append container for buttons at the top of the body
    var buttonContainer = d3.select("#Density_buttons");

    // Add buttons
    buttonContainer.append("button")
        .text("Metro Distance")
        .style('font-size', '20px')
        .style('margin-right', '50px')
        .style('margin-left', '80px')
        .style("font-family", "'Source Sans Pro', sans-serif")
        .classed("button", true)
        .classed('button_metro', true)
        .classed('clicked', true)
        .on("click", function() {
            updateDensityPlot("metro_dist");
            d3.select('.button_metro').classed('clicked', true);
            d3.select('.button_citycenter').classed('clicked', false);
            // Dispatch custom event to synchronize with bar chart for "Metro distance"
            var event = new CustomEvent('densityPlotButtonClicked', { detail: "Metro Distance" });
            document.dispatchEvent(event);
            
        });

    buttonContainer.append("button")
        .text("Distance from City Centre")
        .style('font-size', '20px')
        .style("font-family", "'Source Sans Pro', sans-serif")
        .classed('button_citycenter', true)
        .classed("button", true)
        .classed('clicked', false)
        .on("click", function() {
            updateDensityPlot("dist");
            d3.select('.button_metro').classed('clicked', false);
            d3.select('.button_citycenter').classed('clicked', true);
            // Dispatch custom event to synchronize with bar chart for "Distance from city centre"
            var event = new CustomEvent('densityPlotButtonClicked', { detail: "Distance from City Centre" });
            document.dispatchEvent(event);
        });

    // Initial update
    updateDensityPlot("metro_dist");
    // Listening for custom event to synchronize with bar chart
    document.addEventListener('citySelected', function(event) {
        const selectedCity = event.detail;
        const lines = d3.selectAll(".line");

        if (selectedCity === "All Cities") {
            lines.style("display", "block"); // Shows all lines
        } else {
            lines.style("display", function() {
                return d3.select(this).attr("class").includes(sanitizeClassName(selectedCity)) ? "block" : "none";
            });
        }
    });
    


    // Kernel density estimator
    function kernelDensityEstimator(kernel, X) {
        return function(V) {
            return X.map(function(x) {
                return [x, d3.mean(V, function(v) { return kernel(x - v); })];
            });
        };
    }

    function kernelEpanechnikov(k) {
        return function(v) {
            return Math.abs(v /= k) <= 1 ? 0.75 * (1 - v * v) / k : 0;
        };
    }

    function sanitizeClassName(name) {
        return name.replace(/\s+/g, '_').replace(/[^\w\s]/gi, '');
    }
});
