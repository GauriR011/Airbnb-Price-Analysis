// Initialize the map
// [49, 0.2] are the latitude and longitude
// 5 is the zoom
// mapid2 is the id of the div where the map will appear
var mymap = L.map('mapid2').setView([49, 0.2], 5);

// Add a tile to the map = a background. Comes from OpenStreetmap
L.tileLayer(
    'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>',
    minZoom: 2,
    maxZoom: 18,
}).addTo(mymap);

// Create an SVG layer on the map
var svgLayer = L.svg({ clickable: true });
svgLayer.addTo(mymap);
d3.select(".leaflet-overlay-pane").style("z-index", 2000);

var svg = d3.select("#mapid2").select("svg");
var g = svg.select('g') || svg.append('g');

// Saving the original center and zoom of the map to restore it later when needed.
var originalView = {
    center: mymap.getCenter(),
    zoom: mymap.getZoom()
};

// List of city data which includes IDs, names, coordinates, and related datasets.
var cities = [
    { id: 0, name: "Amsterdam", coords: [52.3676, 4.9041], dataset: null, subset_data: null },
    { id: 1, name: "London", coords: [51.5074, -0.1278], dataset: null, subset_data: null },
    { id: 2, name: "Paris", coords: [48.8566, 2.3522], dataset: null, subset_data: null },
    { id: 3, name: "Berlin", coords: [52.5200, 13.4050], dataset: null, subset_data: null },
    { id: 4, name: "Rome", coords: [41.9028, 12.4964], dataset: null, subset_data: null }
];

// SVG path for the markers, describing the shape of a location pin.
var markerSVG = `<svg width="25" height="31" viewBox="0 0 25 31" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd"
            d="M12.5 23.25C12.9969 23.25 21.875 14.0753 21.875 9.06748C21.875 4.05965 17.6776 0 12.5 0C7.32232 0 3.125 4.05965 3.125 9.06748C3.125 14.0753 12.0031 23.25 12.5 23.25ZM12.5 13.6027C15.1251 13.6027 17.2532 11.5445 17.2532 9.00548C17.2532 6.4665 15.1251 4.40826 12.5 4.40826C9.87493 4.40826 7.74689 6.4665 7.74689 9.00548C7.74689 11.5445 9.87493 13.6027 12.5 13.6027Z"
            fill="#EF1D1D" />
        <path fill-rule="evenodd" clip-rule="evenodd"
            d="M3.125 9.06748C3.125 14.0753 12.0031 23.25 12.5 23.25V13.6027C9.87493 13.6026 7.74689 11.5444 7.74689 9.00548C7.74689 6.46651 9.87493 4.40827 12.5 4.40826V0C7.32233 0 3.125 4.05965 3.125 9.06748Z"
            fill="#FF5151" />
        </svg>`;

// Creating a tooltip div that will show data on hover over the markers.
var tooltip = d3.select("body").append("div")
    .style("top", "200px")
    .style("left", "20px")
    .style("width", "150px")
    .style("height", "70px")
    .style("position", "absolute")
    .style("z-index", "1000")
    .style("position", "absolute")
    .style("visibility", "hidden")
    .style("background", "white")
    .style("border", "1px solid black")
    .style("padding", "5px")
    .style("border-radius", "5px")
    .style("pointer-events", "none")
    .style("font-family", "'Source Sans Pro', sans-serif");

// Back button to reset the map view to the original view.
var backButtonContainer = d3.select('#backArrow')
    .attr('id', 'back-button-container')
    .style('position', 'absolute')
    .style('top', '20px') 
    .style('left', '8px')
    .style('margin-left', '20px')
    .style('z-index', '1000'); 

// SVG path for the back button, describing the shape.
backButtonContainer.html(`<svg width="42" height="25" viewBox="0 0 42 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M38.5914 9.90432H10.4351L17.1879 4.79226C17.7408 4.3719 18.0514 3.80177 18.0514 3.2073C18.0514 2.61282 17.7408 2.04269 17.1879 1.62233C16.6351 1.20197 15.8852 0.96582 15.1034 0.96582C14.3215 0.96582 13.5717 1.20197 13.0188 1.62233L1.27479 10.5517C1.00749 10.764 0.797966 11.0144 0.658228 11.2884C0.364575 11.8319 0.364575 12.4415 0.658228 12.985C0.797966 13.259 1.00749 13.5093 1.27479 13.7216L13.0188 22.651C13.2917 22.8602 13.6165 23.0263 13.9742 23.1396C14.332 23.253 14.7158 23.3113 15.1034 23.3113C15.491 23.3113 15.8747 23.253 16.2325 23.1396C16.5903 23.0263 16.915 22.8602 17.1879 22.651C17.4631 22.4435 17.6815 22.1966 17.8306 21.9245C17.9797 21.6525 18.0564 21.3607 18.0564 21.066C18.0564 20.7713 17.9797 20.4796 17.8306 20.2075C17.6815 19.9355 17.4631 19.6886 17.1879 19.4811L10.4351 14.369H38.5914C39.3701 14.369 40.1169 14.1338 40.6675 13.7152C41.2181 13.2965 41.5274 12.7287 41.5274 12.1367C41.5274 11.5446 41.2181 10.9768 40.6675 10.5582C40.1169 10.1395 39.3701 9.90432 38.5914 9.90432Z"
                fill="black" />
        </svg>`);

backButtonContainer.select('svg')
    .style('cursor', 'pointer')
    .on('click', function () {
        // Get the current view details
        var currentView = {
            center: mymap.getCenter(),
            zoom: mymap.getZoom()
        };

        // Set view to the original center and zoom level
        mymap.setView(originalView.center, originalView.zoom);

        // After setting the view, check if the map view is the same as the original view
        if (currentView.zoom === originalView.zoom && currentView.center.equals(originalView.center)) {
            // Remove the legend and clear the bubble filter only if the views match
            removeLegend();
            clearBubbleFilter();
        }

        // Clear the set maximum bounds and reset the minimum zoom level
        mymap.setMaxBounds(null);
        mymap.setMinZoom(0);
    });

// Function to determine bubble color based on price range for each city
// Low Price -> Green
// Medium Price -> Yellow
// High Price -> Red
function getColorForPrice(city, price) {
    if (city == 0) {  // Amsterdam
        if (price >= 0 && price <= 330) {
            return '#10AF20'; // Low Price - Green
        } else if (price > 330 && price <= 680) {
            return '#FFC700'; // Medium Price - Yellow
        } else if (price > 680) {
            return '#D93737'; // High Price - Red
        } else {
            return '#000000'; // Default color if price is not a number
        }
    } else if (city == 1) {  // London
        if (price >= 0 && price <= 170) {
            return '#10AF20'; 
        } else if (price > 170 && price <= 400) {
            return '#FFC700';
        } else if (price > 400) {
            return '#D93737'; 
        } else {
            return '#000000';
        }
    } else if (city == 2) { // Paris
        if (price >= 0 && price <= 240) {
            return '#10AF20'; 
        } else if (price > 240 && price <= 460) {
            return '#FFC700';
        } else if (price > 460) {
            return '#D93737'; 
        } else {
            return '#000000'; 
        }
    } else if (city == 3) { // Berlin
        if (price >= 0 && price <= 140) {
            return '#10AF20'; 
        } else if (price > 140 && price <= 280) {
            return '#FFC700'; 
        } else if (price > 280) {
            return '#D93737'; 
        } else {
            return '#000000'; 
        }
    } else if (city == 4) { // Rome
        if (price >= 0 && price <= 130) {
            return '#10AF20';
        } else if (price > 130 && price <= 240) {
            return '#FFC700'; 
        } else if (price > 240) {
            return '#D93737';
        } else {
            return '#000000';
        }
    }
}

// Function to determine price category based on the price range for each city
function getPriceCategory(city, price) {
    if (city == 0) {  // Amsterdam
        if (price >= 0 && price <= 330) {
            return "low";
        } else if (price > 330 && price <= 680) {
            return "medium";
        } else if (price > 680) {
            return "high"; 
        } else {
            return "none";
        }
    } else if (city == 1) {  // London
        if (price >= 0 && price <= 170) {
            return "low";
        } else if (price > 170 && price <= 400) {
            return "medium"; 
        } else if (price > 400) {
            return "high";
        } else {
            return "none"; 
        }
    } else if (city == 2) { // Paris
        if (price >= 0 && price <= 240) {
            return "low"; 
        } else if (price > 240 && price <= 460) {
            return "medium"; 
        } else if (price > 460) {
            return "high"; 
        } else {
            return "none"; 
        }
    } else if (city == 3) { // Berlin
        if (price >= 0 && price <= 140) {
            return "low"; 
        } else if (price > 140 && price <= 280) {
            return "medium"; 
        } else if (price > 280) {
            return "high"; 
        } else {
            return "none";
        }
    } else if (city == 4) { // Rome
        if (price >= 0 && price <= 130) {
            return "low"; 
        } else if (price > 130 && price <= 240) {
            return "medium"; 
        } else if (price > 240) {
            return "high"; 
        } else {
            return "none";
        }
    }
}

// Function to filter bubbles on the map by color.
function filterBubblesByColor(color) {
    g.selectAll("circle.bubble")
        .style("display", function (d) {
            var bubbleColor = getColorForPrice(d.city, d.weekday_price || d.weekend_price);
            return bubbleColor === color ? null : "none"; // Hide bubbles that don't match the color
        });
}

// Clear the filter and show all bubbles
function clearBubbleFilter() {
    g.selectAll("circle.bubble")
        .style("display", null);
}

// Function to add a legend to the map.
function addLegend() {

    var mapContainer = d3.select("#mapid2");

    var legend = mapContainer.append("div")
        .attr("class", "legend")
        .style("position", "absolute")
        .style("top", "30px")
        .style("right", "30px")
        .style("background", "white")
        .style("padding", "2px")
        .style("border", "1.5px solid black")
        .style("border-radius", "8px")
        .style("z-index", "1000")
        .style("font-family", "'Source Sans Pro', sans-serif");

    // Add colored circles to legend
    legend.selectAll("div")
        .data([
            { color: 'none', text: 'Select Price:' },
            { color: '#10AF20', text: 'Low Price' },
            { color: '#FFC700', text: 'Medium Price' },
            { color: '#D93737', text: 'High Price' },
            { color: 'none', text: 'Reset' }
        ])
        .enter().append("div")
        .style("padding", "2px")
        .style("display", "flex")
        .style("align-items", "center")
        .style("justify-content", function (d) { return d.color === 'none' ? "center" : "start"; }) // Center only the Reset text
        .style("font-weight", function (d) { return d.text === 'Select Price:' || d.text === 'Reset' ? "bold" : "normal"; })
        .html(function (d) {
            // Check if the entry is for the Reset or Select Price option
            if (d.color === 'none') {
                return d.text; // Only display the text for Reset and Select Price options
            }
            // Otherwise, display the color circle and text
            return `<svg width="20" height="20">
                        <circle cx="10" cy="10" r="7" fill="${d.color}"></circle>
                    </svg> ${d.text}`;
        })
        .on("click", function (_, d) {
            if (d.color === 'none' && d.text === 'Reset') {
                clearBubbleFilter(); // Clear the filter when Reset is clicked
            } else if (d.text === 'Select Price:'){ // Print the statement when select price is clicked
                console.log("Select Price is not a clickable button");
            } else {
                filterBubblesByColor(d.color); // Filter bubbles by color
            }
        });
}

// Function to remove the legend from the map.
function removeLegend() {
    d3.select(".legend").remove();
}

// Function to create bubbles for each city based on the data.
function createCityBubble(cityID) {
    var cityData = cityID;
    // Get the subset_data for clicked city
    cities.forEach(city => {
        if (parseFloat(city.id) == parseFloat(cityID)) {
            cityData = city.subset_data;
        }
    })

    // Get weekday prices or weekend price details from cityData
    var dataPoints = Object.entries(cityData).map(([key, value]) => {
        var [lat, lng] = key.split(',');
        return {
            lat: parseFloat(lat),
            lng: parseFloat(lng),
            weekday_price: parseFloat(value.weekday_price),
            weekend_price: parseFloat(value.weekend_price),
            city: parseFloat(cityID)
        };
    });

    // Create bubbles and color them using the getColorForPrice() function
    var bubbles = g.selectAll("circle.bubble")
        .data(dataPoints)
        .join("circle")
        .attr("class", "bubble")
        .attr("cx", d => mymap.latLngToLayerPoint(L.latLng(d.lat, d.lng)).x)
        .attr("cy", d => mymap.latLngToLayerPoint(L.latLng(d.lat, d.lng)).y)
        .attr("r", 7)
        .style("fill", function (d) {
            if (isNaN(d.weekday_price) && isNaN(d.weekend_price)) {
                console.log("Price doesn't exist!!")
            }
            else if (isNaN(d.weekday_price)) {
                return getColorForPrice(cityID, d.weekend_price)
            }
            else if (isNaN(d.weekend_price)) {
                return getColorForPrice(cityID, d.weekday_price)
            }
            else {
                return getColorForPrice(cityID, d.weekday_price)
            }
        })
        .style("z-index", "2000")
        .style('cursor', 'pointer')
        .style("pointer-events", "all")
        .attr("class", function (d) {
            return "bubble price-category-" + getPriceCategory(d.weekday_price || d.weekend_price);
        });

    // Show tooltip whenever the bubbles are hovered above
    // The tooltip displays the weekend and weekday prices of the Airbnb's.
    // If only one price is retrieved, then it is showed as Price.
    // Else, it is showed differently.
    bubbles.on("mouseover", function (event, d) {
        if (isNaN(d.weekday_price)) {
            tooltip.html(`Price: ${d.weekend_price.toFixed(2)}`)
                .style("left", (event.pageX) + "px")
                .style("top", (event.pageY - 28) + "px")
                .style("visibility", "visible")
                .style("width", "100px")
                .style("height", "20px");
        }
        else if (isNaN(d.weekend_price)) {
            tooltip.html(`Price: ${d.weekday_price.toFixed(2)}`)
                .style("left", (event.pageX) + "px")
                .style("top", (event.pageY - 28) + "px")
                .style("visibility", "visible")
                .style("width", "100px")
                .style("height", "20px");
        }
        else {
            tooltip.html(`Weekday Price: ${d.weekday_price.toFixed(2)}<br>Weekend Price: ${d.weekend_price.toFixed(2)}`)
                .style("left", (event.pageX) + "px")
                .style("top", (event.pageY - 28) + "px")
                .style("visibility", "visible")
                .style("width", "160px")
                .style("height", "40px");
        }
    })
        .on("mousemove", function (event) {
            tooltip.style("left", (event.pageX) + "px")
                .style("top", (event.pageY - 28) + "px");
        })
        .on("mouseout", function () {
            tooltip.style("visibility", "hidden");
        });

    mymap.on("zoomend", updateBubblePositions);
    mymap.on("moveend", updateBubblePositions);
}

// Function to update bubble positions when the map view changes.
function updateBubblePositions() {
    g.selectAll("circle.bubble")
        .attr("cx", d => mymap.latLngToLayerPoint(L.latLng(d.lat, d.lng)).x)
        .attr("cy", d => mymap.latLngToLayerPoint(L.latLng(d.lat, d.lng)).y)
}

// Function to update marker positions, called after data is loaded or the map view changes.
function updateMarkers() {
    // Generate the markers based on the Latitudes and Longitudes of each city defined in cities
    var images = g.selectAll("image")
        .data(cities)
        .join("image")
        .attr('xlink:href', 'data:image/svg+xml;base64,' + btoa(markerSVG))
        .attr('x', d => mymap.latLngToLayerPoint(L.latLng(d.coords)).x - 35 / 2)
        .attr('y', d => mymap.latLngToLayerPoint(L.latLng(d.coords)).y - 30)
        .attr("width", 35)
        .attr("height", 41)
        .style("z-index", "2000");

    // Remove previous rectangles
    g.selectAll("rect").remove();

    // Generate text labels for each city marker with their names
    var labels = g.selectAll("text")
        .data(cities)
        .join("text")
        .attr("x", d => mymap.latLngToLayerPoint(L.latLng(d.coords)).x)
        .attr("y", d => mymap.latLngToLayerPoint(L.latLng(d.coords)).y - 45)
        .text(d => d.name)
        .attr("text-anchor", "middle")
        .attr("fill", "black")
        .style("z-index", "2000")
        .style("font-family", "'Source Sans Pro', sans-serif")
        .style("font-size", "16px")
        .style("pointer-events", "none");

    // For each label, create a white rectangular box around the text
    labels.each(function (d, i) {
        var bbox = this.getBBox();
        var padding = 5;
        var rect = g.insert("rect", "text")
            .attr("x", bbox.x - padding)
            .attr("y", bbox.y - padding)
            .attr("width", bbox.width + (padding * 2))
            .attr("height", bbox.height + (padding * 2))
            .attr("rx", 5)
            .attr("ry", 5)
            .attr("fill", "white")
            .style("z-index", "2000")
            .style("pointer-events", "visiblePainted");

        this.parentNode.appendChild(this);

        // Whenever a rectangle is clicked, the map zooms into the city and creates the scatter plot bubbles/points
        [this, rect.node()].forEach(function (element) {
            d3.select(element).on("click", function (event) {
                mymap.setView(d.coords, 10); // Sets the view to the city's coordinates with a higher zoom level

                // Defines the bounds around the clicked city
                var buffer = 0.05; // This is the buffer in degrees for latitude and longitude
                var southWest = L.latLng(d.coords[0] - buffer, d.coords[1] - buffer);
                var northEast = L.latLng(d.coords[0] + buffer, d.coords[1] + buffer);
                var cityBounds = L.latLngBounds(southWest, northEast);

                mymap.setMaxBounds(cityBounds); // Set the maximum bounds to the city boundaries
                mymap.setMinZoom(mymap.getZoom()); // Prevent zooming out beyond the current zoom level

                if (d.dataset) {
                    // Create bubbles for the clicked city using it's dataset id
                    createCityBubble(d.id);
                    addLegend();
                    mymap.on('moveend', () => createCityBubble(d.id));
                    mymap.on('zoomend', () => createCityBubble(d.id));
                }
            });
        });
    });
}

// Function to extract price details for a specific location.
function get_price_details(data, lat, lng) {
    // Filter the data for the given listing ID
    let listingData = data.filter(listing => parseFloat(listing.lat) == lat && parseFloat(listing.lng) == lng);

    // If coords are not found then return Listing not found
    if (listingData.length === 0) {
        return "Listing not found.";
    }

    // Initialize variables to store total prices and counts for averaging
    let weekdayTotal = 0, weekendTotal = 0;
    let weekdayCount = 0, weekendCount = 0;

    // For each record in the listingData, check if the record is for Weekday or Weekend and update counter
    listingData.forEach(listing => {
        if (parseFloat(listing.day_type) === 0) { // 0 indicates weekdays
            weekdayTotal += parseFloat(listing.realSum);
            weekdayCount++;
        } else if (parseFloat(listing.day_type) === 1) { // 1 indicates weekends
            weekendTotal += parseFloat(listing.realSum);
            weekendCount++;
        }
    });

    // A dictionary to hold the result
    let result = { city: listingData[0].city, lat: listingData[0].lat, lng: listingData[0].lng };
    // If weekday or weekend count is greater than 0, take average of all prices
    if (weekdayCount > 0) {
        result.weekday_price = weekdayTotal / weekdayCount;
    }
    if (weekendCount > 0) {
        result.weekend_price = weekendTotal / weekendCount;
    }

    return result;
}

// Function to extract price details for all locations in the dataset.
function get_all_price_details(data) {
    // Create a unique key for each listing based on its coordinates
    let uniqueKeys = [...new Set(data.map(listing => `${listing.lat},${listing.lng}`))];

    // Object to hold price details for all listings, keyed by their coordinate pairs
    let allPriceDetails = {};

    // Iterate over each unique coordinate pair and fetch price details
    uniqueKeys.forEach(key => {
        // Split the key back into latitude and longitude
        let [lat, lng] = key.split(',').map(Number);
        // console.log(typeof lat, typeof lng)

        // Use the modified function that works with coordinates
        let details = get_price_details(data, lat, lng);

        // Store the details using the coordinate pair as the key
        allPriceDetails[key] = details;
    });

    // Delete any price records that have NaN values
    Object.keys(allPriceDetails).forEach((key) => {
        if (isNaN(allPriceDetails[key].weekday_price) && isNaN(allPriceDetails[key].weekend_price)) {
            console.log("Both weekday and weekend prices don't exist for: ", allPriceDetails[key])
        }
        else if (isNaN(allPriceDetails[key].weekday_price)) {
            delete allPriceDetails[key].weekday_price;
        }
        else if (isNaN(allPriceDetails[key].weekend_price)) {
            delete allPriceDetails[key].weekend_price;
        }
    });

    // Update the subset_data key in cities to hold the price details information
    cities.forEach(city => {
        if (city.id == Object.values(allPriceDetails)[0].city) {
            city.subset_data = allPriceDetails;
        }
    });

    return allPriceDetails;
}

// Update markers initially
updateMarkers();

// Update the marker positions when the map is moved or zoomed
mymap.on('move', updateMarkers);
mymap.on('zoomend', updateMarkers);

// Loading the dataset and, initializing city datasets and city price subset datasets with it.
d3.csv("./data/Final_df.csv").then(function (data) {
    cities.forEach(city => {
        city.dataset = data.filter(d => d.city == city.id);
        get_all_price_details(city.dataset);
    })
    console.log("Data retrieved! ", cities)
})
